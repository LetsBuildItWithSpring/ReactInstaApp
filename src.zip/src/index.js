import reactDOM from "react-dom";
import Login from "./Login";


const root=document.getElementById("react-app");
reactDOM.render(<Login/>, root);